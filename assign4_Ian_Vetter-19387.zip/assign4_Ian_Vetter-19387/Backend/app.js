const express = require('express');
const app = express();
const bodyParser = require('body-parser');

// Middleware to parse JSON and urlencoded form data
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Define the menu with prices
const menu = {
  "coffee": 2.50,
  "tea": 8.99,
  "sandwich": 5.00,
  "salad": 6.00,
  "burger": 7.50
};

// Function to calculate the total bill
function calculateTotal(order) {
  let total = 0;
  for (const [item, quantity] of Object.entries(order)) {
    total += menu[item] * quantity;
  }
  return total.toFixed(2);
}

// Serve HTML form for placing orders
app.get('/', (req, res) => {
  res.sendFile(__dirname + '/order-form.html');
});

// Handle form submission
app.post('/order', (req, res) => {
  const order = req.body;
  const total = calculateTotal(order);
  res.send(`Thank you for your order! Total amount: $${total}`);
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
